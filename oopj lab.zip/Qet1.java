import java.lang.*;
class Qet1
{
public static void main(String args[])
{
int n=123,sum=0;

while(n!=0){

sum=sum+n%10;
n=n/10;
}
System.out.println("Sum of the digit is "+sum);
}
}